# Unity 3D 方块

Unity 3D 方块：完整工程、入口源码与使用说明；可修改后再次运行/编译进行迭代。

## 需要

Unity Editor 与 Windows Build Support

## 操作

1. 帮助 → 示例中心，双击本例创建可编辑副本。
2. 阅读入口源码；窗口例在界面设计页查看控件与事件。
3. F5运行；编译菜单选择目标；停止可取消后台任务。
4. 修改源码或表单后再次运行/构建。原示例不会被覆盖。

## 预期结果

打开Unity后使用PCIDE/Create Demo Scene，再按Play；IDE构建生成game.exe

## 编译与资源

脚本独立EXE会携带运行时；系统环境发布不附带运行时。C/C++静态CRT仍依赖Windows系统DLL。
线程例使用有界池和协作取消，with/RAII/using释放资源。引擎示例需实际本机引擎，未安装时不会假装执行成功。
