from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QApplication, QPlainTextEdit

from pcide.core.project import Project
from pcide.core.runner import ScriptRunner
from pcide.core.package import verify_package
from pcide.ui.form_runtime import RuntimeWindowManager


class Signals(QObject):
    record = Signal(dict)
    done = Signal(int, str)


def main():
    bundle = Path(getattr(sys, "_MEIPASS", Path.cwd()))
    single = (bundle / "package.json").is_file()
    if getattr(sys, "frozen", False):
        import hashlib
        identity = hashlib.sha256(str(Path(sys.executable).resolve()).encode()).hexdigest()[:16]
        os.environ["PCIDE_ROOT"] = os.environ.get("PCIDE_DATA_ROOT") or str(Path(os.environ.get("LOCALAPPDATA", os.environ.get("TEMP", "."))) / "PCIDE/apps" / identity)
    if "--worker" in sys.argv:
        from pcide.core.worker import main as worker_main
        return worker_main()
    if "--plugin_host" in sys.argv:
        from pcide.core.plugin_host import main as plugin_main
        return plugin_main()
    if "--agent_http" in sys.argv:
        from pcide.core.agent_http import main as agent_main
        return agent_main()
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--report")
    args = parser.parse_args()
    root = bundle if single else Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path.cwd()
    if not verify_package(root, "package.json" if single else "build.json", "payload" if single else None):
        raise RuntimeError("project package manifest/file hash verification failed")
    project = Project.open(root / "payload")
    runner = ScriptRunner()
    handlers = []
    form = project.load_form()
    if form["form"].get("events", {}).get("load"):
        handlers.append(form["form"]["events"]["load"])
    if args.verify:
        for window_path in project.window_paths():
            window_form = project.load_window(window_path)
            handlers.extend(c["events"]["click"] for c in window_form["controls"] if c["events"].get("click"))
        code, output, state = runner.run_sync(project, timeout=project.manifest.get("execution", {}).get("timeout_seconds", 60), events=handlers)
        report = {"exit_code": code, "output": output, "error": state.error, "messages": runner.messages,
                  "frozen": bool(getattr(sys, "frozen", False))}
        if args.report:
            Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        # Console protocol is ASCII so it is independent of the Windows code page.
        print(json.dumps(report, ensure_ascii=True))
        return code
    app = QApplication(sys.argv)
    forms = {str(path.resolve()): project.load_window(path) for path in project.window_paths()}
    main_key = str(project.form_path.resolve())
    forms.setdefault(main_key, form)
    manager = RuntimeWindowManager(forms, lambda handler, payload: runner.event(handler, payload))
    signals = Signals()
    output = QPlainTextEdit()
    output.setReadOnly(True)
    output.setWindowTitle(project.manifest["name"] + " - 输出")
    output.document().setMaximumBlockCount(2000)
    def record(message):
        if message.get("kind") in {"stdout", "stderr", "error"}:
            output.appendPlainText(message.get("text", message.get("message", "")))
            if message["kind"] == "error":
                output.show()
        elif message.get("kind") == "ui.set":
            if not manager.update_control(message["id"], message["properties"], message.get("window")):
                output.appendPlainText(f"未知控件: {message['id']}")
        elif message.get("kind") == "ui.window.open":
            try:
                manager.open(message["window"])
                manager.load_event(message["window"])
            except (KeyError, TypeError) as exc:
                output.appendPlainText(f"无法打开运行窗口: {exc}")
        elif message.get("kind") == "ui.window.close":
            try:
                manager.close(message["window"])
            except (KeyError, TypeError) as exc:
                output.appendPlainText(f"无法关闭运行窗口: {exc}")
        elif message.get("kind") == "ready":
            manager.load_event()
    signals.record.connect(record)
    signals.done.connect(lambda code, error: output.appendPlainText(f"Exit {code}: {error}"))
    main_window = manager.open(main_key)
    main_window.closed.connect(app.quit)
    runner.start(project, keep_alive=True, on_message=signals.record.emit,
                 on_done=lambda code, state: signals.done.emit(code, state.error))
    try:
        return app.exec()
    finally:
        runner.stop()
        runner.wait()


if __name__ == "__main__":
    raise SystemExit(main())
