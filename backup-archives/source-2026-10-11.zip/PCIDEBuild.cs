using System;
using System.IO;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
public static class PCIDEBuild {
    [MenuItem("PCIDE/Create Demo Scene")]
    public static void CreateScene() {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene);
        var actor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        actor.AddComponent<GameController>();
        var camera = new GameObject("Camera").AddComponent<Camera>();
        camera.transform.position = new Vector3(0, 2, -6);
        camera.transform.LookAt(actor.transform);
        var light = new GameObject("Light").AddComponent<Light>();
        light.type = LightType.Directional;
        light.transform.rotation = Quaternion.Euler(40, -30, 0);
        Directory.CreateDirectory("Assets/Scenes");
        EditorSceneManager.SaveScene(scene, "Assets/Scenes/Main.unity");
    }
    public static void BuildWindows() {
        var args = Environment.GetCommandLineArgs();
        var index = Array.IndexOf(args, "-pcideOutput");
        if (index < 0 || index + 1 >= args.Length) throw new ArgumentException("pcideOutput required");
        if (!File.Exists("Assets/Scenes/Main.unity")) CreateScene();
        var report = BuildPipeline.BuildPlayer(new[] { "Assets/Scenes/Main.unity" }, args[index + 1],
            BuildTarget.StandaloneWindows64, BuildOptions.None);
        if (report.summary.result != BuildResult.Succeeded) throw new Exception("Unity build failed");
    }
}
