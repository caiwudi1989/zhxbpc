using UnityEngine;
public sealed class GameController:MonoBehaviour { void Update(){ transform.position=new Vector3(Mathf.Sin(Time.time)*2,0,0); } }
