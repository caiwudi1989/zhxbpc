using UnityEngine;
public sealed class GameController : MonoBehaviour {
    public float speed = 60f;
    void Update() { transform.Rotate(0f, 0f, speed * Time.deltaTime); }
}
