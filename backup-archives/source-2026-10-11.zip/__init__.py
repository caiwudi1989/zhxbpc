"""PCIDE package."""
